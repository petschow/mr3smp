/* Copyright (c) 2010, RWTH Aachen University
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or 
 * without modification, are permitted provided that the following
 * conditions are met:
 *   * Redistributions of source code must retain the above 
 *     copyright notice, this list of conditions and the following
 *     disclaimer.
 *   * Redistributions in binary form must reproduce the above 
 *     copyright notice, this list of conditions and the following 
 *     disclaimer in the documentation and/or other materials 
 *     provided with the distribution.
 *   * Neither the name of the RWTH Aachen University nor the
 *     names of its contributors may be used to endorse or promote 
 *     products derived from this software without specific prior 
 *     written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL RWTH 
 * AACHEN UNIVERSITY BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF 
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE.
 *
 * Coded by Matthias Petschow (petschow@aices.rwth-aachen.de),
 * Juni 2013, Version 0.1
 *
 * This code was the result of a collaboration between 
 * Matthias Petschow and Paolo Bientinesi. When you use this 
 * code, kindly reference the paper:
 *
 * "Improved Accuracy and Parallelism for MRRR-based Eigensolvers" 
 * by Matthias Petschow, Enrique S. Quintana-Orti and Paolo Bientinesi 
 * (submitted to SIAM J. Sci. Comp.).
 *
 */

#ifndef SSTRUCTS_H
#define SSTRUCTS_H

#include "global.h"
#include "counter.h"
#include "queue.h"


typedef struct {
  int              n;
  long double *restrict D;
  long double *restrict E;
  long double *restrict E2;
  int              nsplit;
  int    *restrict isplit ;
  long double           spdiam;
} in_t;


typedef struct {
  int              n;
  int              m;
  long double           *vlp;
  long double           *vup;
  int              *ilp;
  int              *iup;
  int              *mp;
  long double *restrict W;
  long double *restrict Werr;
  long double *restrict Wgap;
  int    *restrict Windex;
  int    *restrict iblock;
  long double *restrict Wshifted;
  long double *restrict gersch;
} val_t;


typedef struct {
  int              ldz;
  int              nz;
  double *restrict Z;
  int    *restrict Zsupp;
  int    *restrict Zindex;
} vec_t;


typedef struct {
  long double split;
  long double rtol1;
  long double rtol2;
  long double RQtol;
  long double pivmin;
  long double bsrtol;
} tol_t;


typedef struct {
  queue_t *r_queue;
  queue_t *s_queue;
  queue_t *c_queue;
} workQ_t;


typedef struct {
  long double lambda;
  int    ilocal;
  int    iblock;
  int    ind;
} sort_struct_t;


typedef struct {
  int       tid;
  int       il;
  int       iu;
  int       my_il;
  int       my_iu;
  int       n;
  long double    *restrict D;
  long double    *restrict E;
  long double    *restrict E2;
  long double    *restrict W;
  long double    *restrict Werr;
  int           *restrict Windex;
  long double    *restrict gersch;
  tol_t        *tolstruct;
} aux1_t;


typedef struct {
  int    tid;
  int    nbl;
  int    rf_begin;
  int    rf_end;
  double spdiamd;
  double *Dd;
  double *DE2d;
  val_t  *Wstruct;
  tol_t  *tolstruct;
} aux2_t;


typedef struct {
  int tid;
  int nthreads;
  counter_t *num_left;
  workQ_t   *workQ;
  in_t      *Dstruct;
  val_t     *Wstruct;
  vec_t     *Zstruct;
  tol_t     *tolstruct;
} aux3_t;


#endif
