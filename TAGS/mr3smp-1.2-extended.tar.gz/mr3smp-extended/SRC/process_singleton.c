/* Copyright (c) 2010, RWTH Aachen University
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or 
 * without modification, are permitted provided that the following
 * conditions are met:
 *   * Redistributions of source code must retain the above 
 *     copyright notice, this list of conditions and the following
 *     disclaimer.
 *   * Redistributions in binary form must reproduce the above 
 *     copyright notice, this list of conditions and the following 
 *     disclaimer in the documentation and/or other materials 
 *     provided with the distribution.
 *   * Neither the name of the RWTH Aachen University nor the
 *     names of its contributors may be used to endorse or promote 
 *     products derived from this software without specific prior 
 *     written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL RWTH 
 * AACHEN UNIVERSITY BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF 
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE.
 *
 * Coded by Matthias Petschow (petschow@aices.rwth-aachen.de),
 * Juni 2013, Version 0.1
 *
 * This code was the result of a collaboration between 
 * Matthias Petschow and Paolo Bientinesi. When you use this 
 * code, kindly reference the paper:
 *
 * "Improved Accuracy and Parallelism for MRRR-based Eigensolvers" 
 * by Matthias Petschow, Enrique S. Quintana-Orti and Paolo Bientinesi 
 * (submitted to SIAM J. Sci. Comp.).
 *
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <math.h> 
#include <float.h>
#include "mrrr.h"
#include "rrr.h"
#include "tasks.h"


#define MAXITER       10
#define EMPTY_RQ_ITER 20


static inline void mrrr_dscal(int*, long double*, long double restrict*, int *);


int PMR_process_s_task(singleton_t *sng, int tid, counter_t *num_left, 
		       workQ_t *workQ, val_t *Wstruct, vec_t *Zstruct, 
		       tol_t *tolstruct, long double *work, int *iwork)
{
  /* Inputs */
  int    begin         = sng->begin; 
  int    end           = sng->end;
  int    size          = end - begin + 1;
  int    bl_begin      = sng->bl_begin;
  int    bl_end        = sng->bl_end;
  int    bl_size       = bl_end - bl_begin + 1;
  long double bl_spdiam     = sng->bl_spdiam; 
  rrr_t  *RRR          = sng->RRR;
  long double *restrict D   = RRR->D; 
  long double *restrict L   = RRR->L; 
  long double *restrict DL  = RRR->DL;
  long double *restrict DLL = RRR->DLL;

  int              n        = Wstruct->n;
  long double *restrict W        = Wstruct->W;
  long double *restrict Werr     = Wstruct->Werr;
  long double *restrict Wgap     = Wstruct->Wgap;
  int    *restrict Windex   = Wstruct->Windex;  
  long double *restrict Wshifted = Wstruct->Wshifted;
  int              ldz      = Zstruct->ldz;
  double *restrict Z        = Zstruct->Z;
  int    *restrict isuppZ   = Zstruct->Zsupp;;
  int    *restrict Zindex   = Zstruct->Zindex;
  long double           pivmin   = tolstruct->pivmin;

  /* others */
  int              info, i, k, j, itmp;
  int              IONE = 1;
  long double           DZERO = 0.0;
  long double           tol, lambda, left, right;
  int              i_local;
  size_t           zind;
  long double           gap, lgap, rgap, gaptol, savedgap, tmp;
  bool             usedBS, usedRQ, needBS, wantNC, step2II;
  int      wantNCl;
  int               r;
  int       offset;
  long double           twoeps = 2*LDBL_EPSILON, RQtol = 2*LDBL_EPSILON;
  long double           residual, bstres, bstw; 
  int              i_supmn, i_supmx;
  long double           RQcorr;
  int              negcount;
  int              sgndef, suppsize;
  long double           sigma;
  int              i_Zfrom, i_Zto;
  long double           ztz, norminv, mingma;
  int              count=1;
  long double *z_tmp;

  /* set tolerance parameter */
  tol  = 4.0 * log( (long double) bl_size ) * DBL_EPSILON;

  /* decrement counter */
  PMR_decrement_counter(num_left, size);

  /* Use a temporary vector to save the eigenvector */
  z_tmp = (long double *) malloc(bl_size*sizeof(long double));

  /* loop over all singletons in the task */
  for (i=begin; i<=end; i++) {

    if (bl_size == 1) {
      /* set eigenvector to column of identity matrix */
      zind = Zindex[i];
      memset(&Z[zind*ldz], 0.0, n*sizeof(double) );
      Z[zind*ldz + bl_begin] = 1.0;
      isuppZ[2*zind    ]          = bl_begin + 1;
      isuppZ[2*zind + 1]       = bl_begin + 1;
      continue;
    }

    lambda  = Wshifted[i];  
    left    = Wshifted[i] - Werr[i];
    right   = Wshifted[i] + Werr[i];
    i_local = Windex[i];
    r       = 0;
    
    /* compute left and right gap */
    if (i == bl_begin)
      lgap = LDBL_EPSILON * fmaxl(fabsl(left), fabsl(right));
    else if (i == begin)
      lgap = sng->lgap;
    else
      lgap = Wgap[i-1];

    if (i == bl_end) {
      rgap = LDBL_EPSILON * fmaxl(fabsl(left), fabsl(right));
    } else {
      rgap = Wgap[i];
    }

    gap = fminl(lgap, rgap);

    if ( i == bl_begin || i == bl_end ) {
      gaptol = 0.0;
    } else {
      gaptol = gap * DBL_EPSILON;
    }

    /* initialize lower and upper value of support */
    i_supmn = bl_size;
    i_supmx = 1;

    /* update Wgap so that it holds minimum gap and save the 
     * old value */
    savedgap  = Wgap[i];
    Wgap[i]   = gap;
    
    /* initialize flags indicating if bisection or Rayleigh-Quotient
     * correction was used */
    usedBS = false;
    usedRQ = false;
  
    /* the need for bisection is initially turned off */
    needBS = !TRY_RQC;

    /* IEEE floating point is assumed, so that all 0 bits are 0.0 */
    zind = Zindex[i];
    memset(z_tmp, 0.0, bl_size*sizeof(long double));

    /* inverse iteration with twisted factorization */
    for (k=1; k<=MAXITER; k++) {

      if (needBS == true) { 
	usedBS = true;
	itmp   = r;
	
	offset  = Windex[i] - 1;
	tmp     = Wgap[i]; 
	Wgap[i] = 0.0;
	
	xdrrb_(&bl_size, D, DLL, &i_local, &i_local, &DZERO, 
		&twoeps, &offset, &Wshifted[i], &Wgap[i],
		&Werr[i], work, iwork, &pivmin, &bl_spdiam,
		&itmp, &info);
	assert(info == 0);
	
	Wgap[i] = tmp;
	lambda = Wshifted[i];
	r = 0;
      }
      wantNC = (usedBS == true) ? false : true;
      wantNCl = wantNC;

      /* compute the eigenvector corresponding to lambda */
      xdr1v_(&bl_size, &IONE, &bl_size, &lambda, D, L, DL, DLL,
	      &pivmin, &gaptol, z_tmp, &wantNCl,
	      &negcount, &ztz, &mingma, &r, &isuppZ[2*zind],
	      &norminv, &residual, &RQcorr, work);

      if (k == 1) {
	bstres = residual;
	bstw   = lambda;
      } else if (residual < bstres) {
	bstres = residual;
	bstw   = lambda;
      }
      
      /* update support held */
      i_supmn = imin(i_supmn, isuppZ[2*zind    ]);
      i_supmx = imax(i_supmx, isuppZ[2*zind + 1]);

      /* Convergence test for Rayleigh Quotient Iteration
       * not done if bisection was used */
      if ( !usedBS && residual > tol*gap 
	   && fabsl(RQcorr) > RQtol*fabsl(lambda) ) {
      
	if (i_local <= negcount) {
	  sgndef = -1;    /* wanted eigenvalue lies to the left  */
	} else {
	  sgndef =  1;    /* wanted eigenvalue lies to the right */
	}
	
	if ( RQcorr*sgndef >= 0.0
	     && lambda+RQcorr <= right 
	     && lambda+RQcorr >= left ) {
	  usedRQ = true;
	  if ( sgndef == 1 )
	    left  = lambda;
	  else
	    right = lambda;
	  Wshifted[i] = 0.5*(left + right);
	  lambda     += RQcorr;
	} else { /* bisection is needed */
	  needBS = true;
	}
	
	if ( right-left < RQtol*fabsl(lambda) ) {
	  /* eigenvalue computed to bisection accuracy
	   * => compute eigenvector */
	  usedBS = true;
	} else if ( k == MAXITER-1 ) {
	  /* for last iteration use bisection */
	  needBS = true;
	}
      } else {
	/* go to next iteration */
	break;
      }

    } /* end k */

    /* if necessary call dlar1v to improve error angle by 2nd step */
    step2II = false;
    if ( usedRQ && usedBS && (bstres <= residual) ) {
      lambda = bstw;
      step2II = true;
    }
    if ( step2II == true ) {
      xdr1v_(&bl_size, &IONE, &bl_size, &lambda, D, L, DL, DLL,
	      &pivmin, &gaptol, z_tmp, &wantNCl,
	      &negcount, &ztz, &mingma, &r, &isuppZ[2*zind],
	      &norminv, &residual, &RQcorr, work);
    }
    Wshifted[i] = lambda;
  
    /* ensure vector is okay if support changed in RQI 
     * minus ones because of indices starting from zero */
    i_Zfrom = isuppZ[2*zind    ] - 1;
    i_Zto      = isuppZ[2*zind + 1] - 1;
    i_supmn--;
    i_supmx--;
    if ( i_supmn < i_Zfrom ) {
      for ( k=i_supmn; k < i_Zfrom; k++ ) {
	z_tmp[k] = 0.0;
      }
    }
    if ( i_supmx > i_Zto ) {
      for ( k=i_Zto+1; k <= i_supmx; k++ ) {
	z_tmp[k] = 0.0;
      }
    }
    
    /* normalize eigenvector */
    suppsize = i_Zto - i_Zfrom + 1;
    mrrr_dscal(&suppsize, &norminv, &z_tmp[i_Zfrom], &IONE);

    /* compute support w.r.t. whole matrix
     * block beginning is offset for each support */
    isuppZ[2*zind    ] += bl_begin;
    isuppZ[2*zind + 1] += bl_begin;

    sigma = L[bl_size-1];
    W[i]  = lambda + sigma;
    
    if (i < end)
      Wgap[i] = fmaxl(savedgap, W[i+1]-Werr[i+1] - W[i]-Werr[i]);

    /* Copy temporary eigenvector into Z */
    memset(&Z[zind*ldz], 0.0, n*sizeof(double));

    j = 0;
    for ( k=bl_begin; k <= bl_end; k++ ) {
      Z[zind*ldz+k] = z_tmp[j];
      j++;
    }

    /* Every x iterations process all pendinf r-tasks */
    count++;
    if (count % EMPTY_RQ_ITER == 0)
      PMR_process_r_queue(tid, workQ, Wstruct, tolstruct, work, 
			  iwork);

  } /* end i */

  /* clean up */
  PMR_try_destroy_rrr(RRR);
  free(sng);
  free(z_tmp);
  
  return(0);
}



/* non-optimized, non-threaded DSCAL replacement */
static inline 
void mrrr_dscal(int *n, long double *alpha, long double *restrict x, int *incx)
{
  int i;
  int stride = *incx;
  int size   = *n;
  long double s   = *alpha;

  for (i=0; i<size; i++)
    x[i * stride] *= s; 

  return;
}
