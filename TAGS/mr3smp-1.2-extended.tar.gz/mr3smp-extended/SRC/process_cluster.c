/* Copyright (c) 2010, RWTH Aachen University
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or 
 * without modification, are permitted provided that the following
 * conditions are met:
 *   * Redistributions of source code must retain the above 
 *     copyright notice, this list of conditions and the following
 *     disclaimer.
 *   * Redistributions in binary form must reproduce the above 
 *     copyright notice, this list of conditions and the following 
 *     disclaimer in the documentation and/or other materials 
 *     provided with the distribution.
 *   * Neither the name of the RWTH Aachen University nor the
 *     names of its contributors may be used to endorse or promote 
 *     products derived from this software without specific prior 
 *     written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL RWTH 
 * AACHEN UNIVERSITY BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF 
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE.
 *
 * Coded by Matthias Petschow (petschow@aices.rwth-aachen.de),
 * Juni 2013, Version 0.1
 *
 * This code was the result of a collaboration between 
 * Matthias Petschow and Paolo Bientinesi. When you use this 
 * code, kindly reference the paper:
 *
 * "Improved Accuracy and Parallelism for MRRR-based Eigensolvers" 
 * by Matthias Petschow, Enrique S. Quintana-Orti and Paolo Bientinesi 
 * (submitted to SIAM J. Sci. Comp.).
 *
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <math.h>
#include <float.h>
#include "global.h"
#include "mrrr.h"
#include "counter.h"
#include "queue.h"
#include "tasks.h"
#include "rrr.h"
#include "structs.h"


static inline 
rrr_t* compute_new_rrr(cluster_t *cl, int tid, val_t *Wstruct, 
		       vec_t *Zstruct, tol_t *tolstruct, long double *work, 
		       int *iwork);

static inline 
int refine_eigvals(cluster_t *cl, int tid, int nthreads, 
		   counter_t *num_left, workQ_t *workQ, rrr_t *RRR, 
		   val_t *Wstruct, vec_t *Zstruct, tol_t *tolstruct, 
		   long double *work, int *iwork);


/* Processing a cluster */
int PMR_process_c_task(cluster_t *cl, int tid, int nthreads, 
		       counter_t *num_left, workQ_t *workQ, 
		       val_t *Wstruct, vec_t *Zstruct, tol_t *tolstruct, 
		       long double *work, int *iwork)
{
  /* Inputs */
  int depth    = cl->depth;
  int m        = Wstruct->m;

  /* Others */
  int   info;
  rrr_t *RRR;

  assert(depth < m);

  RRR = compute_new_rrr(cl, tid, Wstruct, Zstruct, tolstruct, 
			work, iwork);

  info = refine_eigvals(cl, tid, nthreads, num_left, workQ, RRR, 
			Wstruct, Zstruct, tolstruct, work, iwork);
  assert(info == 0);
  
  return(0);
}





static inline 
rrr_t* compute_new_rrr(cluster_t *cl, int tid, val_t *Wstruct, 
		       vec_t *Zstruct, tol_t *tolstruct, 
		       long double *work, int *iwork)
{
  int    cl_begin    = cl->begin;
  int    cl_end      = cl->end;
  int    cl_size     = cl_end - cl_begin + 1;
  int    depth       = cl->depth;
  int    bl_begin    = cl->bl_begin;
  int    bl_end      = cl->bl_end;
  int    bl_size     = bl_end - bl_begin + 1;
  long double bl_spdiam   = cl->bl_spdiam;
  rrr_t  *RRR_parent = cl->RRR;

  long double *restrict Werr     = Wstruct->Werr;
  long double *restrict Wgap     = Wstruct->Wgap;
  int    *restrict Windex   = Wstruct->Windex;
  long double *restrict Wshifted = Wstruct->Wshifted;
  long double           RQtol    = tolstruct->RQtol;
  long double           pivmin   = tolstruct->pivmin;

  /* Others */
  long double *restrict D,         *restrict L;
  long double *restrict DL,        *restrict DLL;
  long double *restrict D_parent,  *restrict L_parent;
  long double *DL_parent,          *DLL_parent;

  int    i, k, p, info;
  long double tmp;
  int    offset, IONE=1;
  long double lgap, rgap, tau, fudge, savegap;
  rrr_t  *RRR;

  /* Allocate memory for new representation for cluster */
  DL  = (long double *) malloc(bl_size * sizeof(long double));
  assert(DL != NULL);
  
  DLL = (long double *) malloc(bl_size * sizeof(long double));
  assert(DLL != NULL);

  if (depth == 0) {

    D = RRR_parent->D;
    L = RRR_parent->L;

  } else {
    
    D = (long double *) malloc (bl_size *sizeof(long double));
    assert(D != NULL);
    
    L = (long double *) malloc (bl_size *sizeof(long double));
    assert(L != NULL);

    /* Recompute DL and DLL of parent */
    D_parent = RRR_parent->D;
    L_parent = RRR_parent->L;
    for (i=0; i<bl_size-1; i++) {
	tmp    = D_parent[i]*L_parent[i];
	DL[i]  = tmp;
	DLL[i] = tmp*L_parent[i];
    }
    DL_parent  = DL;
    DLL_parent = DLL;
    
    /* Shift as close as possible refine extremal eigenvalues */
    for (k=0; k<2; k++) {
      if (k == 0) {
	p              = Windex[cl_begin];
	savegap        = Wgap[cl_begin];
	Wgap[cl_begin] = 0.0;
      } else {
	p              = Windex[cl_end];
	savegap        = Wgap[cl_end];
	Wgap[cl_end]   = 0.0;
      }
      
      offset  = Windex[cl_begin] - 1;
      
      xdrrb_(&bl_size, D_parent, DLL_parent, &p, &p, &RQtol,
	      &RQtol, &offset, &Wshifted[cl_begin], &Wgap[cl_begin],
	      &Werr[cl_begin], work, iwork, &pivmin, &bl_spdiam,
	      &bl_size, &info);
      assert(info == 0);
      
      if (k == 0) {
	Wgap[cl_begin] = fmaxl((long double) 0, (Wshifted[cl_begin+1]-Werr[cl_begin+1])
			       - (Wshifted[cl_begin]+Werr[cl_begin]) );
      } else {
	Wgap[cl_end]   = savegap;
      }
    } /* end k */

    /* calculate right and left gaps */
    lgap = cl->lgap;
    rgap = Wgap[cl_end];
    
    /* Compute new RRR and store it in D and L */
    xdrrf_(&bl_size, D_parent, L_parent, DL_parent,
	    &IONE, &cl_size, &Wshifted[cl_begin], &Wgap[cl_begin],
	    &Werr[cl_begin], &bl_spdiam, &lgap, &rgap,
	    &pivmin, &tau, D, L, work, &info);
    assert(info == 0);

    /* update shift and store it */
    tmp = L_parent[bl_size-1] + tau;
    L[bl_size-1] = tmp;
    
    /* update shifted eigenvalues and fudge errors */
    for (k=cl_begin; k<=cl_end; k++) {
      fudge  = 3.0 * LDBL_EPSILON * fabsl( Wshifted[k] );
      Wshifted[k] -= tau;
      fudge += 4.0 * LDBL_EPSILON * fabsl( Wshifted[k] );
      Werr[k] += fudge;
    } 
  } 
  /* D, L is the RRR of the current depth level now */

  /* Compute corresponding D*L and D*L*L */
  for (i=0; i<bl_size-1; i++) {
    tmp    = D[i]*L[i];
    DL[i]  = tmp;
    DLL[i] = tmp*L[i];
  }

  /* For small cluster created new RRR */
  // if (cl_size < 4 && depth > 1) {
  if (RRR_parent->need_free == true) {
    free(D_parent);
    free(L_parent);
  }
    
  RRR = PMR_reset_rrr(RRR_parent, D, L, DL, DLL, bl_size, depth);

  /* Prevend freeing before cluster task processed */
  PMR_increment_rrr_dependencies(RRR);

  return(RRR);
}



static inline 
int refine_eigvals(cluster_t *cl, int tid, int nthreads, 
		   counter_t *num_left, workQ_t *workQ, rrr_t *RRR, 
		   val_t *Wstruct, vec_t *Zstruct, tol_t *tolstruct, 
		   long double *work, int *iwork)
{
  int    cl_begin    = cl->begin;
  int    cl_end      = cl->end;
  int    cl_size     = cl_end - cl_begin + 1;
  int    depth       = cl->depth;
  int    bl_begin    = cl->bl_begin;
  int    bl_end      = cl->bl_end;
  int    bl_size     = bl_end - bl_begin + 1;
  int    bl_W_begin  = cl->bl_W_begin;
  int    bl_W_end    = cl->bl_W_end;
  int    mbl         = bl_W_end - bl_W_begin + 1;

  long double *restrict D        = RRR->D;
  long double *restrict L        = RRR->L;
  long double *restrict DLL      = RRR->DLL;
  int n = Wstruct->n;
  long double *restrict W        = Wstruct->W;
  long double *restrict Werr     = Wstruct->Werr;
  long double *restrict Wgap     = Wstruct->Wgap;
  int    *restrict Windex   = Wstruct->Windex;
  long double *restrict Wshifted = Wstruct->Wshifted;
  long double *restrict gersch   = Wstruct->gersch;
  long double bl_spdiam   = cl->bl_spdiam;

  double *Dd, *DLLd, *workd, *Wd, *Werrd, *Wgapd;
  double           rtol1d    = tolstruct->rtol1;
  double           rtol2d    = tolstruct->rtol2;
  double           pivmind   = tolstruct->pivmin;
  double           spdiamd = bl_spdiam;

  int    i, j, info, offset;
  long double gl, gu, sigma, savegap;
  int    nleft, chunk, own_part, others_part;
  int    rf_begin, rf_end, p, q;
  int    num_tasks, count, taskcount;
  subtasks_t *subtasks;
  task_t *task;

  /* Only needed if xdrrb is called below */
  /* long double           rtol1    = tolstruct->rtol1; */
  /* long double           rtol2    = tolstruct->rtol2; */
  /* long double           pivmin   = tolstruct->pivmin; */

  /* Allocate temporary memory for double precision computations */
  Dd = (double *) malloc(bl_size * sizeof(double));
  assert(Dd != NULL);
  DLLd = (double *) malloc(bl_size * sizeof(double));
  assert(DLLd != NULL);
  Wd = (double *) malloc(n * sizeof(double));
  assert(Wd != NULL);
  Werrd = (double *) malloc(n * sizeof(double));
  assert(Werrd != NULL);
  Wgapd = (double *) malloc(n * sizeof(double));
  assert(Wgapd != NULL);
  workd = (double *) malloc(4*bl_size * sizeof(double));
  assert(workd != NULL);


  if (depth == 0) {

    gl = gersch[2*bl_begin    ];
    gu = gersch[2*bl_begin + 1];
    for (i = bl_begin+1; i<bl_end; i++) {
      gl = fminl(gl, gersch[2*i    ]);
      gu = fmaxl(gu, gersch[2*i + 1]);
    }
    cl->bl_spdiam = gu - gl;

    sigma = L[bl_size-1];

    memcpy(&Wshifted[cl_begin], &W[cl_begin], mbl*sizeof(long double));
    for (i=0; i<mbl; i++) {
      W[cl_begin + i] += sigma;
    }
    
    info = PMR_create_subtasks(cl, tid, nthreads, num_left, workQ, RRR, 
			       Wstruct, Zstruct, tolstruct, work, iwork);
    assert(info == 0);
    
  } else {

    /* Determine if refinement should be split into tasks */
    nleft = PMR_get_counter_value(num_left);
    own_part = (int) fmax( ceil( (double) nleft / nthreads ),
			   MIN_BISEC_CHUNK);
    
    if (own_part < cl_size) {
      /* Parallize refinement the refinement by creating tasks */
      num_tasks   = (int) ceil((double) cl_size / own_part) - 1; /*>1*/

      /* Fudge number of tasks to be cerated in case many threads 
       * are involved to get better load balancing; my first version 
       * had gradual smaller task for even better load balancing, 
       * but I thought through the absolute splitting one could get rid 
       * of fudging */
      /* if (num_tasks >= (int) ceil((1.0-(1.0/NUM_SOCKETS))*nthreads)) { */
      /* 	own_part  = (int) fmax( ceil( (long double) own_part / 2.0 ), */
      /* 			                 MIN_BISEC_CHUNK); */
      /*  num_tasks *= 4; */
      /* }  */

      others_part = cl_size - own_part;
      chunk       = others_part/num_tasks;
      
      subtasks = malloc(sizeof(subtasks_t));
      subtasks->counter = PMR_create_counter(num_tasks + 1);

      subtasks->cl = cl;
      subtasks->nthreads = nthreads;
      subtasks->num_left = num_left;
      subtasks->workQ = workQ;
      subtasks->RRR = RRR;
      subtasks->Zstruct = Zstruct;
      subtasks->num_tasks = num_tasks;
      subtasks->chunk = chunk;
      
      rf_begin = cl_begin;
      p        = Windex[cl_begin];
      for (i=0; i<num_tasks; i++) {
	rf_end = rf_begin + chunk - 1;
	q      = p        + chunk - 1;
	
	task = PMR_create_r_task(rf_begin, rf_end, D, DLL, p, q, bl_size, 
                                                     bl_spdiam, tid, subtasks);
	
	if (rf_begin <= rf_end) {
	  PMR_insert_task_at_back(workQ->r_queue, task);
	} else {
	  free(task->data);
	  free(task);
	  PMR_decrement_counter(subtasks->counter, 1);
	}	

	rf_begin = rf_end + 1;
	p        = q      + 1;
      }
      rf_end = cl_end;
      q      = Windex[cl_end];
      offset = Windex[rf_begin] - 1;

      /* Call bisection routine to refine the values */
      if (rf_begin <= rf_end) {

	/* Prepare double precision computation */
	for (j=0; j<bl_size; j++) {
	  Dd[j] = D[j];
	  DLLd[j] = DLL[j];
	}

	for (j=rf_begin; j<=rf_end; j++) {
	  Wd[j] = Wshifted[j];
	  Werrd[j] = Werr[j];
	  Wgapd[j] = Wgap[j];
	}

	/* xdrrb_(&bl_size, D, DLL, &p, &q, &rtol1, &rtol2, &offset,  */
	/* 	&Wshifted[rf_begin], &Wgap[rf_begin], &Werr[rf_begin], */
	/* 	work, iwork, &pivmin, &bl_spdiam, &bl_size, &info); */
	/* assert( info == 0 ); */

	odrrb_(&bl_size, Dd, DLLd, &p, &q, &rtol1d, &rtol2d, &offset, 
		&Wd[rf_begin], &Wgapd[rf_begin], &Werrd[rf_begin],
		workd, iwork, &pivmind, &spdiamd, &bl_size, &info);
	assert( info == 0 );

	/* Convert double precision eigenvalues to higher precision */
	for (j=rf_begin; j<=rf_end; j++) {
	  Wshifted[j] = Wd[j];
	  Werr[j] = Werrd[j];
	  Wgap[j] = Wgapd[j];
	}

      }
      taskcount = PMR_decrement_counter(subtasks->counter, 1);
      if (taskcount == 0) {
	      /* Edit right gap at splitting point */
	      rf_begin = cl_begin;
	      for (i=0; i<num_tasks; i++) {
		rf_end = rf_begin + chunk - 1;
		
		Wgap[rf_end] = Wshifted[rf_end + 1] - Werr[rf_end + 1]
			       - Wshifted[rf_end] - Werr[rf_end];
	      
		rf_begin = rf_end + 1;
	      }
	      sigma = L[bl_size-1];
	      
	      /* refined eigenvalues with all shifts applied in W */
	      for ( j=cl_begin; j<=cl_end; j++ ) {
		W[j] = Wshifted[j] + sigma;
	      }

	      info = PMR_create_subtasks(cl, tid, nthreads, num_left, workQ, RRR, 
				     Wstruct, Zstruct, tolstruct, work, iwork);
	      assert(info == 0);

	      PMR_destroy_counter(subtasks->counter); 
	      free(subtasks);
      }

    } else {
      /* do refinement of cluster without creating tasks */

      /* Prepare double precision computation */
      for (j=0; j<bl_size; j++) {
	Dd[j] = D[j];
	DLLd[j] = DLL[j];
      }

      for (j=cl_begin; j<=cl_end; j++) {
	Wd[j] = Wshifted[j];
	Werrd[j] = Werr[j];
	Wgapd[j] = Wgap[j];
      }
      
      /* p and q are local (within block) indices of
       * the first/last eigenvalue of the cluster */
      p = Windex[cl_begin];
      q = Windex[cl_end];
      offset = Windex[cl_begin] - 1;
      
      if (p == q) {
	savegap = Wgap[cl_begin];
	Wgapd[cl_begin] = 0.0;
      }  
      
      /* call bisection routine to refine the values to rel. acc. */
      /* xdrrb_(&bl_size, D, DLL, &p, &q, &rtol1, &rtol2, &offset,  */
      /* 	      &Wshifted[cl_begin], &Wgap[cl_begin], &Werr[cl_begin], */
      /* 	      work, iwork, &pivmin, &bl_spdiam, &bl_size, &info); */
      /* assert( info == 0 ); */

      odrrb_(&bl_size, Dd, DLLd, &p, &q, &rtol1d, &rtol2d, &offset, 
	      &Wd[cl_begin], &Wgapd[cl_begin], &Werrd[cl_begin],
	      workd, iwork, &pivmind, &spdiamd, &bl_size, &info);
      assert( info == 0 );

      /* Convert double precision eigenvalues to higher precision */
      for (j=cl_begin; j<=cl_end; j++) {
	Wshifted[j] = Wd[j];
	Werr[j] = Werrd[j];
	Wgap[j] = Wgapd[j];
      }
      
      if (p == q) {
	Wgap[cl_begin] = savegap;
      }  
      
      sigma = L[bl_size-1];
      
      /* refined eigenvalues with all shifts applied in W */
      for (j=cl_begin; j<=cl_end; j++) {
        W[j] = Wshifted[j] + sigma;
      }

      info = PMR_create_subtasks(cl, tid, nthreads, num_left, workQ, RRR, 
                             Wstruct, Zstruct, tolstruct, work, iwork);
      assert(info == 0);

    } /* end refine with or without creating tasks */
  } /* end refining eigenvalues */

  free(Dd);
  free(DLLd);
  free(Wd);
  free(Werrd);
  free(Wgapd);
  free(workd);

  return(0);
}




int PMR_create_subtasks(cluster_t *cl, int tid, int nthreads, 
		    counter_t *num_left, workQ_t *workQ, rrr_t *RRR, 
		    val_t *Wstruct, vec_t *Zstruct, tol_t *tolstruct,
		    long double *work, int *iwork)
{
  /* Inputs */
  int    cl_begin    = cl->begin;
  int    cl_end      = cl->end;
  int    cl_size     = cl_end - cl_begin + 1;
  int    depth       = cl->depth;
  int    bl_begin    = cl->bl_begin;
  int    bl_end      = cl->bl_end;
  int    bl_size     = bl_end - bl_begin + 1;
  int    bl_W_begin  = cl->bl_W_begin;
  int    bl_W_end    = cl->bl_W_end;
  long double bl_spdiam   = cl->bl_spdiam;

  long double *restrict D        = RRR->D;
  long double *restrict L        = RRR->L;
  long double *restrict Wgap     = Wstruct->Wgap;
  long double *restrict Wshifted = Wstruct->Wshifted;
  int              ldz      = Zstruct->ldz;
  double *restrict Z        = Zstruct->Z;
  int    *restrict Zindex   = Zstruct->Zindex;
  
  /* Others */
  int       i, k, j, jj;
  int       new_first, new_last;
  int       new_size;
  size_t    new_ftt0, new_ftt1;
  int       cl_first, cl_last;
  long double    lgap;
  rrr_t     *RRR_parent;
  task_t    *task;
  int       sn_first=-1, sn_last=-1, sn_size=-1;
  int       max_size;
  bool      task_inserted;
  long double    avggap, avggap_factor;

  long double *restrict D_parent;
  long double *restrict L_parent;
  bool need_malloc;

  double minrelgap = MIN_RELGAP;

  max_size = imax(1, PMR_get_counter_value(num_left) /
		     (4*nthreads) );
  task_inserted = true;
  avggap_factor = 2.0;

  /* Set minrelgap: see also mrrr.c (note: delete repeated segment) */
  if (ADJUST_RELGAP) { 
    if (LDBL_EPSILON < 1e-13*DBL_EPSILON) {
      minrelgap = 1e-10;
    } else if (LDBL_EPSILON < 1e-3*DBL_EPSILON) {
      minrelgap = 5e-4;
    } else {
      minrelgap = 1e-3;
    }
  } else {
    minrelgap = MIN_RELGAP;
  }

  new_first = cl_begin;
  for (i=cl_begin; i<=cl_end; i++) {    

    if ( i == cl_end )
      new_last = i;
    else if ( Wgap[i] >= minrelgap*fabsl(Wshifted[i]) )
      new_last = i;
    else
      continue;

    new_size = new_last - new_first + 1;
    
    if (new_size == 1) {
      /* singleton was found */
      
      if (new_first==cl_begin || task_inserted==true) {
	/* initialize new singleton task */
	sn_first = new_first;
	sn_last  = new_first;
	sn_size  = 1;
      } else {
	/* extend singleton task by one */
	sn_last++;
	sn_size++;
      }
      
      /* insert task if ... */
      if (i==cl_end || sn_size>=max_size ||
	  Wgap[i+1] < minrelgap*fabsl(Wshifted[i+1])) {

	if (sn_first == cl_begin) {
	  lgap = cl->lgap;
	} else {
	  lgap = Wgap[sn_first-1];
	}
	
	PMR_increment_rrr_dependencies(RRR);
	
	task = PMR_create_s_task(sn_first, sn_last, depth+1, bl_begin,
				 bl_end, bl_W_begin, bl_W_end, 
				 bl_spdiam, lgap, RRR);

	if (depth > 0 && cl_size < STASK_NOENQUEUE) {
	  PMR_process_s_task((singleton_t *) task->data, tid, num_left, 
			     workQ, Wstruct, Zstruct, tolstruct, work, 
			     iwork);
	  free(task);
	} else {
	  PMR_insert_task_at_back(workQ->s_queue, task);
	}
	  
	task_inserted = true;
      } else {
	task_inserted = false;
      }

    } else {
      /* cluster was found */
      
      if (depth == 0 && new_size > 3) {
	/* split cluster to smaller clusters by an absolute
         * split criterion */
	
	cl_first = new_first;
	cl_last  = new_last;
	avggap   = bl_spdiam / (bl_size-1);

	for (k=new_first+1; k<new_last; k++) {
	  
	  if (k == new_last-1)
	    cl_last = new_last;
	  else if (k != cl_first && Wgap[k] > avggap_factor*avggap)
	    cl_last = k;
	  else
	    continue;

	  /* find gap to the left */
	  if (cl_first == cl_begin) {
	    lgap = cl->lgap;
	  } else {
	    lgap = Wgap[cl_first - 1];
	  }

	  RRR_parent = PMR_create_rrr(D, L, NULL, NULL, bl_size, depth, false);

	  /* Create the task for the cluster and put it in the queue */ 
	  task = PMR_create_c_task(cl_first, cl_last, depth+1, 
				   bl_begin, bl_end, bl_W_begin, 
				   bl_W_end, bl_spdiam, lgap, 
				   RRR_parent);
	  
	  PMR_insert_task_at_back(workQ->c_queue, task);
	  
	  cl_first = k + 1;
	} /* end k */

      } else {
	
	/* find gap to the left */
	if (new_first == cl_begin) {
	  lgap = cl->lgap;
	} else {
	  lgap = Wgap[new_first - 1];
	}
	
	/* Determine if there is space to copy D,L into Z */
	need_malloc = true;
	for (j = new_first; j < new_last; j++) {
	  if (Zindex[j+1] == Zindex[j] + 1) {
	    new_ftt0 = Zindex[j];
	    break;
	  }
	}
	jj = j + 2;
	for (j = jj; j < new_last; j++) {
	  if (Zindex[j+1] == Zindex[j] + 1) {
	    new_ftt1 = Zindex[j];
	    need_malloc = false;
	    break;
	  }
	}

	if (depth == 0) {
	  
	  RRR_parent = PMR_create_rrr(D, L, NULL, NULL, bl_size, depth, false);
	  
	} else {

	  if (new_size < 4 || need_malloc) {

	    /* Create new RRR without using Z as temporary storage; 
	     * just to make it work; really inefficient as the data could be reused; 
	     * also, it is a waste of memory; the idea is that it happens rarely */
	    D_parent = (long double *) malloc(bl_size * sizeof(long double));
	    L_parent = (long double *) malloc(bl_size * sizeof(long double));
	    memcpy(D_parent, D, bl_size * sizeof(long double));
	    memcpy(L_parent, L, bl_size * sizeof(long double));

	    RRR_parent = PMR_create_rrr(D_parent, L_parent,
					NULL, NULL, bl_size, depth, true);
	  } else {

	    /* Copy RRR into Z; note: for double/quad no RRR should be copied 
	       at all (or created as above); instead a depth-first execution should 
	       keep an RRR in memery until its cluster is fully processed */
	    /* memcpy(&Z[new_ftt0*ldz+bl_begin], D, bl_size * sizeof(long double)); */
	    /* memcpy(&Z[new_ftt1*ldz+bl_begin], L, bl_size * sizeof(long double)); */
	    
	    /* RRR_parent = PMR_create_rrr((long double *) &Z[new_ftt0*ldz + bl_begin], */
	    /* 				(long double *) &Z[new_ftt1*ldz + bl_begin], */
	    /* 				NULL, NULL, bl_size, depth); */
	    memcpy(&Z[new_ftt0*ldz], D, bl_size * sizeof(long double));
	    memcpy(&Z[new_ftt1*ldz], L, bl_size * sizeof(long double));
	    
	    RRR_parent = PMR_create_rrr((long double *) &Z[new_ftt0*ldz],
					                        (long double *) &Z[new_ftt1*ldz],
					NULL, NULL, bl_size, depth, false);
	  }
	}
	
	/* Create the task for the cluster and put it in the queue */ 
	task = PMR_create_c_task(new_first, new_last, depth+1, 
				 bl_begin, bl_end, bl_W_begin, 
				 bl_W_end, bl_spdiam, lgap, 
				 RRR_parent);

	if ( (new_size < 4 || need_malloc) && depth > 0) {
	  PMR_insert_task_at_front(workQ->c_queue, task);
	} else {	
	  PMR_insert_task_at_back(workQ->c_queue, task);
	}
      }	
      
      task_inserted = true;
      
    } /* if singleton or cluster found */

    new_first = i + 1;
  }  /* end i */

  /* Set flag in RRR that last singleton is created */
  PMR_set_parent_processed_flag(RRR);
  
  /* Clean up */
  PMR_try_destroy_rrr(RRR);
  free(cl);

  return(0);
} /* end PMR_create_subtasks */
